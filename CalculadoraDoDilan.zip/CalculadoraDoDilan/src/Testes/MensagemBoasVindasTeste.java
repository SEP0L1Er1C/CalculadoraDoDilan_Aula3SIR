package Testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Fontes.MensagemBoasVindas;

public class MensagemBoasVindasTeste {

	//Preparação de testes
		public MensagemBoasVindas mensUsuario;
		@Before
		public void prepTeste() {
			String mensx = "Nome Teste";
			mensUsuario = new MensagemBoasVindas(mensx);   
		}  
			
		//Teste da mensagem de abertura
		@Test
		public void t01testeCriarMensRecepcao() {
		    String mensretorno = mensUsuario.exibirMensAbertura();
			assertEquals("Ola! Seja bem vindo a sua calculadora pessoal,", mensretorno);     
		}
		   
		//Teste da mensagem complementar
	   @Test
	   public void t02testeExibeMensComplementar() {
		  String mensRetornoEsperado = "Nome Teste!/nConfira os resultados dos testes no painel da JUNIT!";	
	      String mensRetornoReal = mensUsuario.exibirMensComplemento();
	      assertEquals(mensRetornoEsperado, mensRetornoReal);     
	   }

	}
